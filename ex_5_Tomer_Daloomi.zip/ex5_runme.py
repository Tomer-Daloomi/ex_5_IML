import GradientDescentMethods as gdm
import readMnist as rm
import numpy as np
import matplotlib.pyplot as plt

T = list(range(1, 150))

data, labels = rm.readMnist()
curr_data, curr_labels = rm.genMnistDigits([0, 1], 500, data, labels)

# replace all 0's with -1's
curr_labels[curr_labels == 0] = -1
# add a 1's column at the end of the data matrix, in order to make the problem linear,
# rather than affine
curr_data = np.concatenate((curr_data, np.ones((1000, 1))), axis=1)

# cut the data into training and testing portions (defined to be 90% for tr and 10% for tst)
tr_data = curr_data[0:900]
tst_data = curr_data[900:1000]

tr_labels = curr_labels[0:900]
tst_labels = curr_labels[900:1000]

# calculate the hypothesis using SGD for 3 different batch sizes,
sgd_avg_w_vals_batch_5 = gdm.SGD(curr_data, curr_labels, 150, 1, 5)
sgd_avg_w_vals_batch_50 = gdm.SGD(curr_data, curr_labels, 150, 1, 50)
sgd_avg_w_vals_batch_150 = gdm.SGD(curr_data, curr_labels, 150, 1, 150)

# calculate the hypothesis using GD
gd_avg_w_vals = gdm.GD(curr_data, curr_labels, 150, 1)

# calculate their training errors
sgd_batch_5_tr_err = gdm.testError(sgd_avg_w_vals_batch_5, tr_data, tr_labels)
sgd_batch_50_tr_err = gdm.testError(sgd_avg_w_vals_batch_50, tr_data, tr_labels)
sgd_batch_150_tr_err = gdm.testError(sgd_avg_w_vals_batch_150, tr_data, tr_labels)
gd_tr_err = gdm.testError(gd_avg_w_vals, tr_data, tr_labels)

# calculate their test errors
sgd_batch_5_tst_err = gdm.testError(sgd_avg_w_vals_batch_5, tst_data, tst_labels)
sgd_batch_50_tst_err = gdm.testError(sgd_avg_w_vals_batch_50, tst_data, tst_labels)
sgd_batch_150_tst_err = gdm.testError(sgd_avg_w_vals_batch_150, tst_data, tst_labels)
gd_tst_err = gdm.testError(gd_avg_w_vals, tst_data, tst_labels)

# execution of paragraph 3/c for the training losses
plt.plot(T, gd_tr_err, 'r', label="GD training errors")
plt.plot(T, sgd_batch_5_tr_err, 'g', label="SGD training errors for batches of 5 samples")
plt.plot(T, sgd_batch_50_tr_err, 'c', label="SGD training errors for batches of 50 samples")
plt.plot(T, sgd_batch_150_tr_err, 'b', label="SGD training errors for batches of 150 samples")
plt.xlabel("T - number of iterations")
plt.ylabel("0-1 Loss (Error)")
plt.legend(loc=1)
plt.show()

# execution of paragraph 3/c for the test losses
plt.plot(T, gd_tst_err, 'r', label="GD testing errors")
plt.plot(T, sgd_batch_5_tst_err, 'g', label="SGD testing errors for batches of 5 samples")
plt.plot(T, sgd_batch_50_tst_err, 'c', label="SGD testing errors for batches of 50 samples")
plt.plot(T, sgd_batch_150_tst_err, 'b', label="SGD testing errors for batches of 150 samples")
plt.xlabel("T - number of iterations")
plt.ylabel("0-1 Loss (Error)")
plt.legend(loc=1)
plt.show()

# execution of paragraph 3/d

# first we take the 1 off the from the end of the weights vector
d = np.shape(sgd_avg_w_vals_batch_5)[0]
sgd_avg_w_vals_batch_5 = np.delete(sgd_avg_w_vals_batch_5, d - 1, 0)
sgd_avg_w_vals_batch_50 = np.delete(sgd_avg_w_vals_batch_50, d - 1, 0)
sgd_avg_w_vals_batch_150 = np.delete(sgd_avg_w_vals_batch_150, d - 1, 0)
gd_avg_w_vals = np.delete(gd_avg_w_vals, d - 1, 0)

# now, we shall use the showImage function in readMinst in order to visually show our weights
iterations = [5, 15, 50, 100]
for iteration in iterations:
    rm.showImage(sgd_avg_w_vals_batch_5[:, iteration])
    plt.show()
    rm.showImage(sgd_avg_w_vals_batch_50[:, iteration])
    plt.show()
    rm.showImage(sgd_avg_w_vals_batch_150[:, iteration])
    plt.show()
    rm.showImage(gd_avg_w_vals[:, iteration])
    plt.show()
