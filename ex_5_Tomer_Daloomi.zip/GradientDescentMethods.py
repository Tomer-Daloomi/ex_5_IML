import numpy as np


def GD(data, labels, iters, eta):
    """
    the function performs the gradient descent technique over

    :param data: n X d matrix, n samples of dimension d
    :param labels: n X 1 matrix with the labels of each sample
    :param iters: an integer - defines the number of iterations to conduct
    :param eta: positive number - defines the learning rate
    :return: d X iters matrix, in which i'th column contains the output of the SGD algorithm over
     i iterations/
    """
    n, d = np.shape(data)
    w_vals, summed_w = np.zeros((iters,d)), np.zeros(d)
    avg_w_vals = []

    # let us calculate the the value of w after each step, and the average value of w up to each
    # point - over T iterations
    for t in range(1, iters):
        # calculate the next (closer) hyperplane value
        w_vals[t] = w_vals[t - 1] - eta * hinge_loss_grad(data, labels, w_vals[t - 1])
        summed_w += w_vals[t]
        # calculate the average w value so far
        avg_w_vals.append(summed_w / (t + 1))

    return np.array(avg_w_vals).transpose()


def SGD(data, labels, iters, eta, batch):
    """
    same as the GD, only now we train our w over specific batches out of the original training data
    :param data: see GD
    :param labels: ""
    :param iters: ""
    :param eta: ""
    :param batch: amount of samples that the algorithm would draw and use at each iteration
    :return: see GD
    """
    n, d = np.shape(data)
    w_vals, summed_w = np.zeros((iters, d)), np.zeros(d)
    avg_w_vals = []
    # let us calculate the the value of w after each step, and the average value of w up to each
    # point - over T iterations
    for t in range(1, iters):
        # for each iteration - we use a subgroup of the data matrix and labels vector (consisting
        # "batch" samples and labels)
        curr_batch_ind = np.random.choice(n, batch, replace=False)
        sub_data = data[curr_batch_ind]
        sub_labels = labels[curr_batch_ind]
        # calculate the next (closer) hyperplane value
        w_vals[t] = w_vals[t - 1] - eta * hinge_loss_grad(sub_data, sub_labels, w_vals[t - 1])
        summed_w += w_vals[t]
        # calculate the average w value so far
        avg_w_vals.append(summed_w / (t + 1))

    return np.array(avg_w_vals).transpose()


def testError(w, test_data, test_labels):
    """
    computes the test error using the 0-1 loss function

    :param w: d X l matrix, where l is the amount of linear hypothesis that we would like to
    examine, each of which are defined using a d- dimensional vector
    :param test_data: n X d matrix with the samples
    :param test_labels: d X 1 matrix with the labels of the samples
    :return: l X 1 matrix with 0-1 loss for each hypothesis. (sign of inner product as label)
    """
    d, l = np.shape(w)
    n = test_data.shape[0]
    loss_vector = []

    for i in range(l):
        curr_w = w[:, i]
        curr_pred = np.sign(np.inner(test_data, curr_w))
        diff = sum([1 if test_labels[j] != curr_pred[j] else 0 for j in range(n)])
        error = diff / n
        loss_vector.append(error)

    return np.array(loss_vector)


def hinge_loss_grad(X, labels, w):
    """
    the function claculates the relevant sub gradient of
    :param X:
    :param labels:
    :param w:
    :return: the averge hinge loss gradient (vector)
    """
    samples = len(labels)
    d = len(X[0])

    hl_gradient = np.zeros(d)

    for i in range(samples):
        if labels[i] * np.inner(X[i], w) < 1:  # if the current sample is being wrongly
            # classified by the current value of w - we shall add the gradient of of this
            # expression to the overall hinge_lost gradient
            hl_gradient -= labels[i] * X[i]

    # eventually, we return the average value of the hinge loss gradient over all the samples
    return hl_gradient / samples
